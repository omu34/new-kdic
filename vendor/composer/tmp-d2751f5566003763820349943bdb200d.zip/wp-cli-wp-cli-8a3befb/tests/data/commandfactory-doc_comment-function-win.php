<?php

/**
 * foo
 */
function commandfactorytests_get_doc_comment_func_1_win( $function = blah ) {
}

/**
 * bar
 function*/function commandfactorytests_get_doc_comment_func_2_win( $function = blah ) {
}

/**
 * /** baz
 */$commandfactorytests_get_doc_comment_func_3_win
  =
  	function ( $args ) {
};
