<?php

namespace WP_CLI\Iterators;

use RuntimeException;

class Exception extends RuntimeException {}
