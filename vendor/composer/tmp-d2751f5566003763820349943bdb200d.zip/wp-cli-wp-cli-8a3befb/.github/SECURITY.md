# Reporting Security Issues

Thanks for wanting to help keep WP-CLI and the larger WordPress community secure!

The WP-CLI team and WordPress community take security bugs seriously. We appreciate your efforts to responsibly disclose your findings, and will make every effort to acknowledge your contributions.

To report a security issue, please visit the [WordPress HackerOne program](https://hackerone.com/wordpress).

